const express = require("express");
const bodyParser = require("body-parser");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const db = new sqlite3.Database("database.db");

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, "public")));

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      price REAL,
      stock INTEGER
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      product_id INTEGER,
      quantity INTEGER,
      FOREIGN KEY(product_id) REFERENCES products(id)
    )
  `);

  db.run(`INSERT OR IGNORE INTO products (id, name, price, stock) VALUES
    (1, 'Lipstick', 999, 10),
    (2, 'Foundation', 1999, 8),
    (3, 'Jeans', 2499, 6)
  `);
});

app.post("/order", (req, res) => {
  const { product_id, quantity } = req.body;

  db.get("SELECT stock FROM products WHERE id = ?", [product_id], (err, row) => {
    if (err) return res.status(500).send("Database error");

    if (!row || row.stock < quantity) {
      return res.send("Product not available or out of stock");
    }

    db.run("INSERT INTO orders (product_id, quantity) VALUES (?, ?)", [product_id, quantity]);
    db.run("UPDATE products SET stock = stock - ? WHERE id = ?", [quantity, product_id]);

    res.send("Order placed successfully!");
  });
});

app.listen(3000, () => {
  console.log("Server running at http://localhost:3000");
});
