function loadCart() {
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  let cartBody = document.getElementById('cart-body');
  let subtotal = 0;
  let hasOutOfStock = false; // flag to check

  cartBody.innerHTML = '';

  if (cart.length === 0) {
    cartBody.innerHTML = '<tr><td colspan="6">Your cart is empty.</td></tr>';
    document.getElementById('subtotal').innerText = '$0.00';
    document.querySelector('.checkout-btn').style.display = 'none';
    return;
  }

  cart.forEach((item, index) => {
    // Randomly mark half items as out of stock
    let outOfStock = Math.random() < 0.5;
    if (outOfStock) hasOutOfStock = true;

    let row = document.createElement('tr');
    if (outOfStock) row.classList.add('out-of-stock');

    row.innerHTML = `
      <td><img src="images/placeholder.jpg" alt="${item.name}"></td>
      <td>${item.name} ${outOfStock ? '(Out of Stock)' : ''}</td>
      <td>$${item.price.toFixed(2)}</td>
      <td>${outOfStock ? '-' : `<input type="number" value="1" min="1" class="qty-input">`}</td>
      <td class="row-total">${outOfStock ? '-' : `$${item.price.toFixed(2)}`}</td>
      <td><button class="remove-btn">Remove</button></td>
    `;

    if (!outOfStock) subtotal += item.price;
    cartBody.appendChild(row);
  });

  document.getElementById('subtotal').innerText = `$${subtotal.toFixed(2)}`;

  // Disable or hide the checkout button if any item is out of stock
  const checkoutBtn = document.querySelector('.checkout-btn');
  if (hasOutOfStock) {
    checkoutBtn.disabled = true;
    checkoutBtn.style.opacity = 0.5;
    checkoutBtn.style.cursor = 'not-allowed';
    checkoutBtn.innerText = 'Some Items Out of Stock';
  } else {
    checkoutBtn.disabled = false;
    checkoutBtn.innerText = 'Proceed to Checkout';
    checkoutBtn.style.opacity = 1;
    checkoutBtn.style.cursor = 'pointer';
  }
}
