document.getElementById('contact-form')?.addEventListener('submit', function (e) {
  e.preventDefault();

  const name = document.getElementById('name');
  const email = document.getElementById('email');
  const message = document.getElementById('message');
  const formMessage = document.getElementById('form-message');
  const loader = document.querySelector('.btn-loader');
  const btnText = document.querySelector('.btn-text');

  if (name.value.trim() === '' || email.value.trim() === '' || message.value.trim() === '') {
    formMessage.textContent = "Please fill in all fields!";
    formMessage.style.color = "red";
    formMessage.classList.remove("hidden");
    return;
  }

  // Show loading
  loader.style.display = "inline-block";
  btnText.textContent = "Sending...";

  setTimeout(() => {
    loader.style.display = "none";
    btnText.textContent = "Send";
    formMessage.textContent = `Thank you, ${name.value.trim()}! We'll be in touch soon.`;
    formMessage.style.color = "green";
    formMessage.classList.remove("hidden");
    name.value = '';
    email.value = '';
    message.value = '';
  }, 1500);
});